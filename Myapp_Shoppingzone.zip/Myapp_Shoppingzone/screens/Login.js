import React from "react";
import {view} from "react-native";

export default function Login() {

    return <view></view>;
}
